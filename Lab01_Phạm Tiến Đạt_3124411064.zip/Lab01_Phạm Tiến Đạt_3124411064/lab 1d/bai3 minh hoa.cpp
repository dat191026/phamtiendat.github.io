﻿#include <iostream>
#include <string>

using namespace std;

void TachVaInTu(const string& s) {
    string word = "";

    for (char c : s) {
        if (c != ' ') { // Nếu ký tự không phải khoảng trắng, thêm vào từ
            word += c;
        }
        else if (!word.empty()) { // Khi gặp khoảng trắng, in từ ra nếu có
            cout << "\"" << word << "\"" << endl;
            word = ""; // Đặt lại từ mới
        }
    }

    // In từ cuối cùng nếu có
    if (!word.empty()) {
        cout << "\"" << word << "\"" << endl;
    }
}

int main() {
    string s;
    cout << "Moi ban nhap chuoi s: ";
    getline(cin, s);

    cout << "Cac tu trong chuoi \"" << s << "\":" << endl;
    TachVaInTu(s);

    return 0;
}
