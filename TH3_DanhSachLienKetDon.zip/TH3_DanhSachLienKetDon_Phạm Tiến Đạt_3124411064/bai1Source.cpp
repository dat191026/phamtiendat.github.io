﻿#include <iostream>
using namespace std;

// Cấu trúc Node
struct Node {
    int data;
    Node* next;
};

// Cấu trúc danh sách liên kết
struct ListInt {
    Node* head; // Con trỏ đầu danh sách
};

// Khởi tạo danh sách
void initializeList(ListInt& list) {
    list.head = NULL;
}

// Hủy danh sách
void destroyList(ListInt& list) {
    Node* current = list.head;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        delete temp; // Giải phóng bộ nhớ
    }
    list.head = NULL;
}

// Thêm phần tử vào danh sách
void addElement(ListInt& list, int value) {
    Node* newNode = new Node; // Tạo node mới
    newNode->data = value;
    newNode->next = NULL;

    if (list.head == NULL) { // Nếu danh sách rỗng
        list.head = newNode;
    }
    else {
        Node* current = list.head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
}

// Xóa phần tử khỏi danh sách
void removeElement(ListInt& list, int value) {
    Node* current = list.head;
    Node* previous = NULL;

    while (current != NULL) {
        if (current->data == value) { // Tìm phần tử cần xóa
            if (previous == NULL) {
                list.head = current->next; // Nếu phần tử ở đầu danh sách
            }
            else {
                previous->next = current->next;
            }
            delete current;
            return;
        }
        previous = current;
        current = current->next;
    }
}

// Thêm danh sách thứ hai vào danh sách thứ nhất
void addList(ListInt& list1, ListInt& list2) {
    if (list1.head == NULL) {
        list1.head = list2.head; // Nếu danh sách 1 rỗng
    }
    else {
        Node* current = list1.head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = list2.head;
    }
    list2.head = NULL; // Làm rỗng danh sách 2
}

// In danh sách
void printList(ListInt& list) {
    Node* current = list.head;
    while (current != NULL) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

// Chương trình chính
int main() {
    ListInt list1, list2;
    initializeList(list1);
    initializeList(list2);

    // Nhập 10 số nguyên vào danh sách 1
    cout << "Nhap 10 so nguyen: ";
    for (int i = 0; i < 10; i++) {
        int value;
        cin >> value;
        addElement(list1, value);
    }

    // In danh sách 1
    cout << "Danh sach 1: ";
    printList(list1);

    // Nhập và xóa một số k
    cout << "Nhap so can xoa: ";
    int k;
    cin >> k;
    removeElement(list1, k);
    cout << "Danh sach 1 sau khi xoa: ";
    printList(list1);

    // Nhập 5 số nguyên vào danh sách 2
    cout << "Nhap 5 so nguyen cho danh sach 2: ";
    for (int i = 0; i < 5; i++) {
        int value;
        cin >> value;
        addElement(list2, value);
    }

    // Gộp danh sách 2 vào danh sách 1
    addList(list1, list2);
    cout << "Danh sach 1 sau khi gop: ";
    printList(list1);

    // Hủy danh sách
    destroyList(list1);
    destroyList(list2);

    return 0;
}
