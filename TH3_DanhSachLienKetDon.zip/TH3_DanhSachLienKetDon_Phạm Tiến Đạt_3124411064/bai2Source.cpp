﻿#include <iostream>
#include <string>
using namespace std;

// Cấu trúc SinhVien
struct SinhVien {
    string hoTen;
    string diaChi;
    string lop;
    int khoa;

    void nhap() {
        cout << "Nhap ho ten: "; getline(cin, hoTen);
        cout << "Nhap dia chi: "; getline(cin, diaChi);
        cout << "Nhap lop: "; getline(cin, lop);
        cout << "Nhap khoa: "; cin >> khoa; cin.ignore();
    }

    void xuat() {
        cout << "Ho Ten: " << hoTen
            << ", Dia Chi: " << diaChi
            << ", Lop: " << lop
            << ", Khoa: " << khoa << endl;
    }
};

// Node của danh sách liên kết
struct Node {
    SinhVien data;
    Node* next;
};

// Danh sách liên kết
struct ListSV {
    Node* head = nullptr;

    // Thêm sinh viên
    void themSinhVien(SinhVien sv) {
        Node* newNode = new Node{ sv, nullptr };
        if (!head) head = newNode;
        else {
            Node* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = newNode;
        }
    }

    // Xuất danh sách
    void xuatDanhSach() {
        Node* temp = head;
        while (temp) {
            temp->data.xuat();
            temp = temp->next;
        }
    }

    // Xóa sinh viên theo tên
    void xoaSinhVienTheoTen(string ten) {
        while (head && head->data.hoTen == ten) {
            Node* del = head;
            head = head->next;
            delete del;
        }
        Node* temp = head;
        while (temp && temp->next) {
            if (temp->next->data.hoTen == ten) {
                Node* del = temp->next;
                temp->next = temp->next->next;
                delete del;
            }
            else temp = temp->next;
        }
    }

    // Xóa sinh viên theo địa chỉ
    void xoaSinhVienTheoDiaChi(string diaChi) {
        while (head && head->data.diaChi == diaChi) {
            Node* del = head;
            head = head->next;
            delete del;
        }
        Node* temp = head;
        while (temp && temp->next) {
            if (temp->next->data.diaChi == diaChi) {
                Node* del = temp->next;
                temp->next = temp->next->next;
                delete del;
            }
            else temp = temp->next;
        }
    }
};

// Chương trình chính
int main() {
    ListSV ds;
    SinhVien sv;

    // Nhập 10 sinh viên
    for (int i = 0; i < 10; ++i) {
        cout << "Nhap sinh vien thu " << i + 1 << ":\n";
        sv.nhap();
        ds.themSinhVien(sv);
    }

    cout << "\nDanh sach sinh vien:\n";
    ds.xuatDanhSach();

    // Xóa sinh viên "Nguyen Van Teo"
    cout << "\nXoa sinh vien co ten 'Nguyen Van Teo':\n";
    ds.xoaSinhVienTheoTen("Nguyen Van Teo");
    ds.xuatDanhSach();

    // Xóa sinh viên có địa chỉ "Nguyen Van Cu"
    cout << "\nXoa sinh vien co dia chi 'Nguyen Van Cu':\n";
    ds.xoaSinhVienTheoDiaChi("Nguyen Van Cu");
    ds.xuatDanhSach();

    // Thêm sinh viên mới
    SinhVien svMoi{ "Tran Thi Mo", "25 Hong Bang", "TT0901", 2009 };
    cout << "\nThem sinh vien 'Tran Thi Mo':\n";
    ds.themSinhVien(svMoi);
    ds.xuatDanhSach();

    return 0;
}
