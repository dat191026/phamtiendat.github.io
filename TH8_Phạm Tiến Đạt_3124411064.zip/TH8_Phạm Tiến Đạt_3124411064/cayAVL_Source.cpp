#include <iostream>
using namespace std;

// ??nh ngh?a c?u tr�c Node
struct Node {
    int info;
    Node* left;
    Node* right;
    int height;
};

// H�m l?y chi?u cao c?a n�t
int GetHeight(Node* p) {
    return (p == NULL) ? 0 : p->height;
}

// H�m t�nh c�n b?ng chi?u cao
int GetBalance(Node* p) {
    return (p == NULL) ? 0 : GetHeight(p->left) - GetHeight(p->right);
}

// H�m t?o n�t m?i
Node* CreateNode(int key) {
    Node* node = new Node();
    node->info = key;
    node->height = 1;
    node->left = NULL;
    node->right = NULL;
    return node;
}

// Ph�p quay ??n RR
Node* RotateRight(Node* y) {
    Node* x = y->left;
    Node* T = x->right;

    x->right = y;
    y->left = T;

    y->height = max(GetHeight(y->left), GetHeight(y->right)) + 1;
    x->height = max(GetHeight(x->left), GetHeight(x->right)) + 1;

    return x;
}

// Ph�p quay ??n LL
Node* RotateLeft(Node* x) {
    Node* y = x->right;
    Node* T = y->left;

    y->left = x;
    x->right = T;

    x->height = max(GetHeight(x->left), GetHeight(x->right)) + 1;
    y->height = max(GetHeight(y->left), GetHeight(y->right)) + 1;

    return y;
}

// H�m th�m n�t
Node* Insert(Node* node, int key) {
    if (node == NULL)
        return CreateNode(key);

    if (key < node->info)
        node->left = Insert(node->left, key);
    else if (key > node->info)
        node->right = Insert(node->right, key);
    else
        return node;

    node->height = 1 + max(GetHeight(node->left), GetHeight(node->right));
    int balance = GetBalance(node);

    // C�c tr??ng h?p quay
    if (balance > 1 && key < node->left->info)
        return RotateRight(node);
    if (balance < -1 && key > node->right->info)
        return RotateLeft(node);
    if (balance > 1 && key > node->left->info) {
        node->left = RotateLeft(node->left);
        return RotateRight(node);
    }
    if (balance < -1 && key < node->right->info) {
        node->right = RotateRight(node->right);
        return RotateLeft(node);
    }

    return node;
}

// H�m t�m ki?m n�t
Node* Find(Node* node, int key) {
    if (node == NULL || node->info == key)
        return node;
    if (key < node->info)
        return Find(node->left, key);
    return Find(node->right, key);
}

// H�m l?y gi� tr? nh? nh?t
Node* GetMinValueNode(Node* node) {
    Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}

// H�m x�a n�t
Node* Delete(Node* root, int key) {
    if (root == NULL)
        return root;

    if (key < root->info)
        root->left = Delete(root->left, key);
    else if (key > root->info)
        root->right = Delete(root->right, key);
    else {
        if ((root->left == NULL) || (root->right == NULL)) {
            Node* temp = root->left ? root->left : root->right;

            if (temp == NULL) {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp;

            delete temp;
        }
        else {
            Node* temp = GetMinValueNode(root->right);
            root->info = temp->info;
            root->right = Delete(root->right, temp->info);
        }
    }

    if (root == NULL)
        return root;

    root->height = 1 + max(GetHeight(root->left), GetHeight(root->right));
    int balance = GetBalance(root);

    // C�c tr??ng h?p quay
    if (balance > 1 && GetBalance(root->left) >= 0)
        return RotateRight(root);
    if (balance > 1 && GetBalance(root->left) < 0) {
        root->left = RotateLeft(root->left);
        return RotateRight(root);
    }
    if (balance < -1 && GetBalance(root->right) <= 0)
        return RotateLeft(root);
    if (balance < -1 && GetBalance(root->right) > 0) {
        root->right = RotateRight(root->right);
        return RotateLeft(root);
    }

    return root;
}

// Duy?t c�y theo th? t? NLR
void PreOrder(Node* root) {
    if (root != NULL) {
        cout << root->info << " ";
        PreOrder(root->left);
        PreOrder(root->right);
    }
}

// Ch??ng tr�nh ch�nh
int main() {
    Node* root = NULL;

    root = Insert(root, 10);
    root = Insert(root, 20);
    root = Insert(root, 30);
    root = Insert(root, 40);
    root = Insert(root, 50);
    root = Insert(root, 25);

    cout << "Duy?t c�y AVL theo NLR: ";
    PreOrder(root);

    root = Delete(root, 40);
    cout << "\nDuy?t c�y AVL sau khi x�a 40: ";
    PreOrder(root);

    return 0;
}
