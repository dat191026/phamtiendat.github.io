﻿#include <iostream>
using namespace std;

// Định nghĩa cấu trúc Node
struct Node {
    int info;
    Node* left;
    Node* right;
};

// Hàm tạo node mới
Node* CreateNode(int x) {
    Node* p = new Node;
    if (p != NULL) {
        p->info = x;
        p->left = NULL;
        p->right = NULL;
    }
    return p;
}

// Hàm khởi tạo cây rỗng
void Init(Node*& t) {
    t = NULL;
}

// Hàm duyệt cây theo thứ tự NLR
void PreOrder(Node* t) {
    if (t != NULL) {
        cout << t->info << " "; // N
        PreOrder(t->left);      // L
        PreOrder(t->right);     // R
    }
}

// Chương trình chính
int main() {
    Node* root;
    Init(root); // Khởi tạo cây rỗng

    // Tạo cây nhị phân
    root = CreateNode(15);
    root->left = CreateNode(7);
    root->right = CreateNode(20);
    root->left->left = CreateNode(3);
    root->left->right = CreateNode(10);
    root->right->left = CreateNode(17);
    root->right->right = CreateNode(25);

    // Duyệt cây theo NLR
    cout << "Duyệt cây theo NLR: ";
    PreOrder(root);

    return 0;
}
