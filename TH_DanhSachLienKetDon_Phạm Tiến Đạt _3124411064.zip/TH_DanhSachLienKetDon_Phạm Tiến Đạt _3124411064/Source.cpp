﻿#include <iostream>
using namespace std;

// Định nghĩa cấu trúc Node
struct Node {
    int info;
    Node* next;
};

// Khởi tạo danh sách rỗng
void Init(Node*& pHead) {
    pHead = NULL;
}

// Kiểm tra danh sách có rỗng không
bool IsEmpty(Node* pHead) {
    return (pHead == NULL);
}

// Tạo một nút mới
Node* CreateNode(int x) {
    Node* p = new Node;
    p->info = x;
    p->next = NULL;
    return p;
}

// Thêm phần tử vào đầu danh sách
void InsertFirst(Node*& pHead, int x) {
    Node* p = CreateNode(x);
    p->next = pHead;
    pHead = p;
}

// Xóa phần tử đầu tiên
void DeleteFirst(Node*& pHead) {
    if (pHead != NULL) {
        Node* p = pHead;
        pHead = pHead->next;
        delete p;
    }
}

// Tìm kiếm một phần tử
Node* Find(Node* pHead, int x) {
    Node* p = pHead;
    while (p != NULL) {
        if (p->info == x) {
            return p;
        }
        p = p->next;
    }
    return NULL;
}

// Duyệt danh sách liên kết
void ShowList(Node* pHead) {
    Node* p = pHead;
    while (p != NULL) {
        cout << p->info << " ";
        p = p->next;
    }
    cout << endl;
}

// Xóa toàn bộ danh sách
void ClearList(Node*& pHead) {
    Node* p;
    while (pHead != NULL) {
        p = pHead;
        pHead = pHead->next;
        delete p;
    }
}

// Hàm chính
int main() {
    Node* pHead;
    Init(pHead);

    // Thêm phần tử vào danh sách
    InsertFirst(pHead, 5);
    InsertFirst(pHead, 20);
    InsertFirst(pHead, 30);

    cout << "Danh sach hien tai: ";
    ShowList(pHead);

    // Tìm kiếm phần tử
    int x = 20;
    Node* found = Find(pHead, x);
    if (found != NULL) {
        cout << "Tim thay phan tu: " << found->info << endl;
    }
    else {
        cout << "Khong tim thay phan tu." << endl;
    }

    // Xóa phần tử đầu
    DeleteFirst(pHead);
    cout << "Danh sach sau khi xoa phan tu dau: ";
    ShowList(pHead);

    // Xóa toàn bộ danh sách
    ClearList(pHead);
    cout << "Danh sach sau khi xoa toan bo: ";
    ShowList(pHead);

    return 0;
}
