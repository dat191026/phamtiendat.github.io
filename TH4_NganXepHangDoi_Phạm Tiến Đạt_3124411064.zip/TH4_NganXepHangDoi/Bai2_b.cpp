#include<iostream>
#include<queue>
#include<string.h>
using namespace std;

struct Node {
    char data[50];
    Node* next;
};

struct LinkedQueueInt {
    Node* front; // Con trỏ đầu của hàng đợi
    Node* rear;  // Con trỏ cuối của hàng đợi
};

// Khởi tạo hàng đợi rỗng
void Init(LinkedQueueInt& queue) {
    queue.front = NULL;
    queue.rear = NULL;
}

// Kiểm tra hàng đợi rỗng
bool IsEmpty(LinkedQueueInt& queue) {
    return (queue.front == NULL && queue.rear == NULL);
}

// Thêm phần tử vào hàng đợi
void Enqueue(LinkedQueueInt& queue, const char* name) {
    Node* temp = new Node;         // Khởi tạo node mới
    strcpy(temp->data, name);      // Gán giá trị cho node
    temp->next = NULL;             // Node mới không trỏ đến node nào
    if (IsEmpty(queue)) {
        queue.front = queue.rear = temp; // Front và rear cùng trỏ đến node mới
    }
    else {
        queue.rear->next = temp;   // Rear trỏ đến node mới
        queue.rear = temp;         // Cập nhật rear là node mới
    }
}

// Loại bỏ phần tử khỏi hàng đợi
void Dequeue(LinkedQueueInt& queue) {
    if (IsEmpty(queue)) {
        cout << "Hang doi rong!\n";
        return;
    }
    Node* temp = queue.front;           // Lưu trữ node đầu để xóa
    queue.front = queue.front->next;    // Cập nhật front là node tiếp theo
    delete temp;                        // Xóa node đầu
    // Nếu hàng đợi rỗng
    if (queue.front == NULL) {
        queue.rear = NULL;              // Đặt rear về NULL
    }
}

// Lấy giá trị phần tử đầu hàng đợi mà không xóa
const char* PeekQueue(LinkedQueueInt& queue) {
    if (!IsEmpty(queue)) {
        return queue.front->data;       // Trả về dữ liệu ở phần tử đầu tiên
    }
    return NULL;
}

int main() {
    LinkedQueueInt maleQueue, femaleQueue;
    Init(maleQueue);
    Init(femaleQueue);

    // Thêm các bạn nam và nữ vào hàng đợi
    Enqueue(maleQueue, "Nam 1");
    Enqueue(maleQueue, "Nam 2");
    Enqueue(femaleQueue, "Nu 1");
    Enqueue(femaleQueue, "Nu 2");

    // Xếp cặp
    while (!IsEmpty(maleQueue) && !IsEmpty(femaleQueue)) {
        const char* male = PeekQueue(maleQueue); // Lấy tên nam từ hàng đợi
        Dequeue(maleQueue); // Xóa nam khỏi hàng đợi
        const char* female = PeekQueue(femaleQueue); // Lấy tên nữ từ hàng đợi
        Dequeue(femaleQueue); // Xóa nữ khỏi hàng đợi
        cout << "Cap: " << male << " va " << female << endl; // In ra cặp nam nữ
    }

    return 0;
}
